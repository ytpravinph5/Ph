import { useState, useRef, useEffect } from 'react';
import { 
  Film, 
  Wand2, 
  Play, 
  Pause, 
  Download, 
  Sparkles, 
  Image as ImageIcon, 
  Mic, 
  Clapperboard,
  Loader2,
  CheckCircle2,
  RefreshCw,
  Volume2,
  Settings,
  Brain,
  Zap,
  Users,
  Music,
  Type,
  Palette,
  Clock,
  Target,
  TrendingUp,
  ChevronRight,
  ChevronLeft,
  Star,
  Heart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { toast } from 'sonner';
import { 
  generateMovieScript, 
  generateSceneImage, 
  generateVoiceover, 
  generateBackgroundMusic,
  compileVideo,
  analyzePrompt,
  retryWithBackoff,
  type Scene,
  type MovieScript,
  type GenerationSettings 
} from '@/services/aiService';
import './App.css';

// Types
interface MovieProject {
  id: string;
  title: string;
  prompt: string;
  script: MovieScript | null;
  scenes: Scene[];
  backgroundMusic?: string;
  status: 'idle' | 'analyzing' | 'generating_script' | 'generating_scenes' | 'generating_audio' | 'compiling' | 'completed';
  progress: number;
  createdAt: Date;
}

interface MovieTemplate {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  prompt: string;
  settings: Partial<GenerationSettings>;
}

// Movie Templates
const movieTemplates: MovieTemplate[] = [
  {
    id: 'sci-fi',
    name: 'Sci-Fi Adventure',
    description: 'Space exploration, futuristic technology, alien worlds',
    icon: <Zap className="w-5 h-5" />,
    prompt: 'A lone astronaut discovers an ancient alien artifact on a distant planet that holds the key to humanity\'s future.',
    settings: { imageStyle: 'realistic', musicGenre: 'epic', sceneCount: 6 },
  },
  {
    id: 'romance',
    name: 'Romantic Drama',
    description: 'Love stories, emotional journeys, heartwarming moments',
    icon: <Heart className="w-5 h-5" />,
    prompt: 'Two strangers meet at a train station and their lives become intertwined in unexpected ways.',
    settings: { imageStyle: 'cinematic', musicGenre: 'romantic', sceneCount: 5 },
  },
  {
    id: 'mystery',
    name: 'Mystery Thriller',
    description: 'Suspense, detective stories, unexpected twists',
    icon: <Brain className="w-5 h-5" />,
    prompt: 'A detective investigates a series of mysterious disappearances in a small town with dark secrets.',
    settings: { imageStyle: 'noir', musicGenre: 'mysterious', sceneCount: 7 },
  },
  {
    id: 'fantasy',
    name: 'Fantasy Epic',
    description: 'Magic, mythical creatures, epic quests',
    icon: <Sparkles className="w-5 h-5" />,
    prompt: 'A young wizard embarks on a quest to find a legendary artifact that can save their kingdom from darkness.',
    settings: { imageStyle: 'fantasy', musicGenre: 'epic', sceneCount: 8 },
  },
  {
    id: 'comedy',
    name: 'Comedy',
    description: 'Humor, funny situations, light-hearted entertainment',
    icon: <Star className="w-5 h-5" />,
    prompt: 'A group of friends attempt to start a business together with hilarious consequences.',
    settings: { imageStyle: 'animated', musicGenre: 'upbeat', sceneCount: 5 },
  },
  {
    id: 'horror',
    name: 'Horror',
    description: 'Suspense, fear, supernatural elements',
    icon: <Target className="w-5 h-5" />,
    prompt: 'A family moves into an old house and discovers it holds a terrifying secret from the past.',
    settings: { imageStyle: 'realistic', musicGenre: 'horror', sceneCount: 6 },
  },
];

// Movie Preview Component
function MoviePreview({ 
  project, 
  settings,
  onExport 
}: { 
  project: MovieProject; 
  settings: GenerationSettings;
  onExport: () => void;
}) {
  const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [volume, setVolume] = useState(80);
  const [showNarration, setShowNarration] = useState(true);
  const controlsTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const progressIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const totalDuration = project.scenes.reduce((acc, scene) => acc + scene.duration, 0);
  const currentScene = project.scenes[currentSceneIndex];

  useEffect(() => {
    if (!isPlaying) return;

    const sceneDuration = currentScene?.duration || 5;
    const progressStep = 100 / (sceneDuration * 30);

    progressIntervalRef.current = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          if (currentSceneIndex < project.scenes.length - 1) {
            setCurrentSceneIndex(prev => prev + 1);
            return 0;
          } else {
            setIsPlaying(false);
            return 100;
          }
        }
        return prev + progressStep;
      });
    }, 33);

    return () => {
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
    };
  }, [isPlaying, currentSceneIndex, project.scenes.length, currentScene?.duration]);

  useEffect(() => {
    setProgress(0);
  }, [currentSceneIndex]);

  const togglePlayback = () => setIsPlaying(!isPlaying);

  const handleSceneClick = (index: number) => {
    setCurrentSceneIndex(index);
    setProgress(0);
    setIsPlaying(false);
  };

  const handlePrevious = () => {
    if (currentSceneIndex > 0) {
      setCurrentSceneIndex(prev => prev - 1);
      setProgress(0);
    }
  };

  const handleNext = () => {
    if (currentSceneIndex < project.scenes.length - 1) {
      setCurrentSceneIndex(prev => prev + 1);
      setProgress(0);
    }
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getCurrentTime = () => {
    let time = 0;
    for (let i = 0; i < currentSceneIndex; i++) time += project.scenes[i].duration;
    time += (progress / 100) * (currentScene?.duration || 5);
    return time;
  };

  return (
    <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-white flex items-center gap-2">
            <Play className="w-5 h-5 text-purple-400" />
            {project.script?.title || 'Movie Preview'}
          </CardTitle>
          <CardDescription className="text-white/50">
            {project.script?.genre} • {project.scenes.length} scenes • {formatTime(totalDuration)}
          </CardDescription>
        </div>
        <div className="flex gap-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  onClick={() => setShowNarration(!showNarration)}
                  className={`border-white/20 ${showNarration ? 'text-purple-400' : 'text-white/50'} hover:bg-white/10`}
                >
                  <Type className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Toggle Narration</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <Button
            variant="outline"
            onClick={togglePlayback}
            className="border-white/20 text-white hover:bg-white/10"
          >
            {isPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {isPlaying ? 'Pause' : 'Play'}
          </Button>
          <Button
            onClick={onExport}
            className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Video Player */}
        <div 
          ref={containerRef}
          className="aspect-video bg-black rounded-xl overflow-hidden relative shadow-2xl"
          onMouseMove={handleMouseMove}
          onMouseLeave={() => isPlaying && setShowControls(false)}
        >
          {currentScene?.imageUrl ? (
            <>
              <img
                src={currentScene.imageUrl}
                alt={`Scene ${currentSceneIndex + 1}`}
                className={`w-full h-full object-cover transition-all duration-700 ${
                  isPlaying ? 'scale-105' : 'scale-100'
                }`}
              />
              
              {/* Scene Info Overlay */}
              <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
                <Badge className="bg-black/60 text-white border-0 backdrop-blur-sm">
                  Scene {currentSceneIndex + 1} / {project.scenes.length}
                </Badge>
                <div className="flex gap-2">
                  {settings.includeNarration && (
                    <Badge className="bg-purple-500/60 text-white border-0 backdrop-blur-sm">
                      <Mic className="w-3 h-3 mr-1" />
                      Narration
                    </Badge>
                  )}
                  {project.script?.scenes[currentSceneIndex]?.mood && (
                    <Badge className="bg-pink-500/60 text-white border-0 backdrop-blur-sm">
                      {project.script.scenes[currentSceneIndex].mood}
                    </Badge>
                  )}
                </div>
              </div>

              {/* Narration Text */}
              {showNarration && project.script?.scenes[currentSceneIndex]?.narration && (
                <div className={`absolute bottom-24 left-4 right-4 transition-opacity duration-300 ${
                  showControls ? 'opacity-100' : 'opacity-0'
                }`}>
                  <div className="bg-black/70 backdrop-blur-md rounded-lg p-4 max-w-2xl mx-auto">
                    <p className="text-white/90 text-sm text-center italic">
                      "{project.script.scenes[currentSceneIndex].narration}"
                    </p>
                  </div>
                </div>
              )}

              {/* Play/Pause Overlay */}
              {!isPlaying && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                  <Button
                    size="lg"
                    onClick={togglePlayback}
                    className="w-24 h-24 rounded-full bg-purple-500/80 hover:bg-purple-600 backdrop-blur-sm transition-transform hover:scale-110"
                  >
                    <Play className="w-10 h-10 ml-1" />
                  </Button>
                </div>
              )}

              {/* Controls */}
              <div className={`absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent pt-20 pb-4 px-4 transition-opacity duration-300 ${
                showControls || !isPlaying ? 'opacity-100' : 'opacity-0'
              }`}>
                {/* Progress Bar */}
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs text-white/70 font-mono">{formatTime(getCurrentTime())}</span>
                    <div className="flex-1 h-1.5 bg-white/20 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-white/40 rounded-full"
                        style={{ width: `${((currentSceneIndex + progress / 100) / project.scenes.length) * 100}%` }}
                      />
                    </div>
                    <span className="text-xs text-white/70 font-mono">{formatTime(totalDuration)}</span>
                  </div>
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-purple-500 rounded-full transition-all"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

                {/* Control Buttons */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handlePrevious}
                      disabled={currentSceneIndex === 0}
                      className="text-white hover:bg-white/20 disabled:opacity-30"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={togglePlayback}
                      className="text-white hover:bg-white/20 w-12 h-12"
                    >
                      {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-0.5" />}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleNext}
                      disabled={currentSceneIndex === project.scenes.length - 1}
                      className="text-white hover:bg-white/20 disabled:opacity-30"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </Button>
                  </div>

                  <div className="flex items-center gap-3">
                    {/* Volume Control */}
                    <div className="flex items-center gap-2">
                      <Volume2 className="w-4 h-4 text-white/70" />
                      <Slider
                        value={[volume]}
                        onValueChange={([v]) => setVolume(v)}
                        min={0}
                        max={100}
                        className="w-20"
                      />
                    </div>
                    <Badge variant="outline" className="border-white/30 text-white/70">
                      <Music className="w-3 h-3 mr-1" />
                      {settings.musicGenre}
                    </Badge>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="w-full h-full flex items-center justify-center text-white/50">
              <Loader2 className="w-8 h-8 animate-spin mr-2" />
              Loading scene...
            </div>
          )}
        </div>

        {/* Scene Timeline */}
        <div>
          <h3 className="text-sm font-medium text-white/70 mb-3">Scene Timeline</h3>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {project.scenes.map((scene, index) => (
              <div
                key={scene.id}
                className={`flex-shrink-0 w-32 cursor-pointer group ${
                  index === currentSceneIndex ? 'ring-2 ring-purple-500 rounded-lg' : ''
                }`}
                onClick={() => handleSceneClick(index)}
              >
                <div className={`aspect-video rounded-lg overflow-hidden bg-white/5 border transition-all ${
                  index === currentSceneIndex 
                    ? 'border-purple-500' 
                    : 'border-white/10 group-hover:border-purple-500/50'
                }`}>
                  {scene.imageUrl && (
                    <img 
                      src={scene.imageUrl} 
                      alt="" 
                      className={`w-full h-full object-cover transition-transform ${
                        index === currentSceneIndex ? 'scale-110' : 'group-hover:scale-105'
                      }`} 
                    />
                  )}
                </div>
                <div className="flex items-center justify-between mt-1">
                  <p className={`text-xs ${index === currentSceneIndex ? 'text-purple-400' : 'text-white/50'}`}>
                    Scene {index + 1}
                  </p>
                  <span className="text-xs text-white/30">{scene.duration}s</span>
                </div>
                {index === currentSceneIndex && isPlaying && (
                  <div className="h-0.5 bg-white/10 rounded-full mt-1 overflow-hidden">
                    <div className="h-full bg-purple-500 rounded-full" style={{ width: `${progress}%` }} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Movie Stats */}
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white/5 rounded-lg p-4">
            <p className="text-xs text-white/50 mb-1">Total Scenes</p>
            <p className="text-2xl font-bold text-white">{project.scenes.length}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-4">
            <p className="text-xs text-white/50 mb-1">Duration</p>
            <p className="text-2xl font-bold text-white">{formatTime(totalDuration)}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-4">
            <p className="text-xs text-white/50 mb-1">Style</p>
            <p className="text-2xl font-bold text-white capitalize">{settings.imageStyle}</p>
          </div>
          <div className="bg-white/5 rounded-lg p-4">
            <p className="text-xs text-white/50 mb-1">Genre</p>
            <p className="text-2xl font-bold text-white capitalize">{project.script?.genre || 'Drama'}</p>
          </div>
        </div>

        {/* Characters */}
        {project.script?.characters && project.script.characters.length > 0 && (
          <div>
            <h3 className="text-sm font-medium text-white/70 mb-3 flex items-center gap-2">
              <Users className="w-4 h-4" />
              Characters
            </h3>
            <div className="flex gap-3">
              {project.script.characters.map((char, index) => (
                <div key={index} className="bg-white/5 rounded-lg p-3 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                    {char.name[0]}
                  </div>
                  <div>
                    <p className="text-white font-medium">{char.name}</p>
                    <p className="text-xs text-white/50">{char.personality}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function App() {
  const [project, setProject] = useState<MovieProject | null>(null);
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentTab, setCurrentTab] = useState('create');
  const [selectedScene, setSelectedScene] = useState<Scene | null>(null);
  const [settings, setSettings] = useState<GenerationSettings>({
    sceneCount: 5,
    imageStyle: 'cinematic',
    voiceType: 'neutral',
    musicGenre: 'emotional',
    includeNarration: true,
    includeDialogue: true,
    language: 'en',
    targetAudience: 'general',
    pacing: 'medium',
  });
  const [showSettings, setShowSettings] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [promptAnalysis, setPromptAnalysis] = useState<ReturnType<typeof analyzePrompt> | null>(null);
  const [generationLogs, setGenerationLogs] = useState<string[]>([]);

  // Analyze prompt when it changes
  useEffect(() => {
    if (prompt.trim()) {
      const analysis = analyzePrompt(prompt);
      setPromptAnalysis(analysis);
    } else {
      setPromptAnalysis(null);
    }
  }, [prompt]);

  // Add log
  const addLog = (message: string) => {
    setGenerationLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${message}`]);
  };

  // Generate movie
  const generateMovie = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a movie prompt!');
      return;
    }

    setIsGenerating(true);
    setGenerationLogs([]);
    
    const newProject: MovieProject = {
      id: Date.now().toString(),
      title: 'Untitled Movie',
      prompt,
      script: null,
      scenes: [],
      status: 'analyzing',
      progress: 0,
      createdAt: new Date(),
    };
    setProject(newProject);

    try {
      // Step 1: Analyze Prompt
      addLog('Analyzing prompt for genre, mood, and key elements...');
      await simulateDelay(1000);
      const analysis = analyzePrompt(prompt);
      addLog(`Detected genre: ${analysis.genre}, Mood: ${analysis.mood}`);
      newProject.progress = 5;
      setProject({ ...newProject });

      // Step 2: Generate Script
      addLog('Generating movie script with AI...');
      newProject.status = 'generating_script';
      setProject({ ...newProject });
      
      const script = await retryWithBackoff(() => generateMovieScript(prompt, settings));
      newProject.script = script;
      newProject.title = script.title;
      newProject.progress = 20;
      setProject({ ...newProject });
      addLog(`Script generated: "${script.title}" with ${script.scenes.length} scenes`);

      // Step 3: Generate Scenes
      addLog('Generating scene images with AI...');
      newProject.status = 'generating_scenes';
      setProject({ ...newProject });

      const scenes: Scene[] = [];
      for (let i = 0; i < script.scenes.length; i++) {
        const sceneData = script.scenes[i];
        addLog(`Generating image for Scene ${i + 1}: ${sceneData.setting}...`);
        
        const imageUrl = await retryWithBackoff(() => 
          generateSceneImage(
            sceneData.description,
            settings.imageStyle,
            sceneData.mood,
            sceneData.lighting
          )
        );
        
        scenes.push({
          id: `scene-${i}`,
          description: sceneData.description,
          imageUrl,
          duration: settings.pacing === 'slow' ? 7 : settings.pacing === 'fast' ? 3 : 5,
          order: i,
          narration: sceneData.narration,
          dialogue: sceneData.dialogue.map(d => `${d.character}: ${d.line}`).join('\n'),
        });
        
        newProject.progress = 20 + Math.round((i + 1) / script.scenes.length * 50);
        setProject({ ...newProject });
      }
      
      newProject.scenes = scenes;
      addLog(`All ${scenes.length} scene images generated successfully`);

      // Step 4: Generate Audio
      addLog('Generating voiceovers and background music...');
      newProject.status = 'generating_audio';
      setProject({ ...newProject });

      if (settings.includeNarration) {
        for (let i = 0; i < scenes.length; i++) {
          if (scenes[i].narration) {
            addLog(`Generating voiceover for Scene ${i + 1}...`);
            const audioUrl = await retryWithBackoff(() => 
              generateVoiceover(scenes[i].narration!, settings.voiceType, settings.language)
            );
            scenes[i].audioUrl = audioUrl;
          }
        }
      }

      const musicUrl = await retryWithBackoff(() => 
        generateBackgroundMusic(settings.musicGenre, scenes.length * 5, 'emotional')
      );
      newProject.backgroundMusic = musicUrl;
      newProject.progress = 90;
      setProject({ ...newProject });
      addLog('Audio generation complete');

      // Step 5: Compile
      addLog('Compiling final movie...');
      newProject.status = 'compiling';
      setProject({ ...newProject });
      
      await simulateDelay(2000);
      newProject.status = 'completed';
      newProject.progress = 100;
      setProject({ ...newProject });
      
      addLog('Movie generation complete!');
      toast.success('Movie generated successfully!');
      setCurrentTab('preview');
    } catch (error) {
      toast.error('Failed to generate movie: ' + (error as Error).message);
      addLog(`Error: ${(error as Error).message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Apply template
  const applyTemplate = (template: MovieTemplate) => {
    setPrompt(template.prompt);
    setSettings({ ...settings, ...template.settings });
    setShowTemplates(false);
    toast.success(`Template "${template.name}" applied!`);
  };

  // Export movie
  const exportMovie = async () => {
    if (!project) return;
    
    toast.info('Preparing movie for export...');
    try {
      const videoBlob = await compileVideo(
        project.scenes,
        project.backgroundMusic || '',
        (progress) => {
          toast.info(`Compiling video: ${progress}%`);
        }
      );
      
      const url = URL.createObjectURL(videoBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${project.title.replace(/\s+/g, '_')}.mp4`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast.success('Movie exported successfully!');
    } catch (error) {
      toast.error('Export failed: ' + (error as Error).message);
    }
  };

  // Reset project
  const resetProject = () => {
    setProject(null);
    setPrompt('');
    setGenerationLogs([]);
    setCurrentTab('create');
    toast.info('Project reset');
  };

  // Regenerate scene
  const regenerateScene = async (sceneId: string) => {
    if (!project?.script) return;
    
    toast.info('Regenerating scene...');
    const sceneIndex = project.scenes.findIndex(s => s.id === sceneId);
    if (sceneIndex === -1) return;

    try {
      const sceneData = project.script.scenes[sceneIndex];
      const newImageUrl = await generateSceneImage(
        sceneData.description,
        settings.imageStyle,
        sceneData.mood,
        sceneData.lighting
      );
      
      const updatedScenes = [...project.scenes];
      updatedScenes[sceneIndex] = {
        ...updatedScenes[sceneIndex],
        imageUrl: newImageUrl,
      };
      
      setProject({ ...project, scenes: updatedScenes });
      toast.success('Scene regenerated!');
    } catch (error) {
      toast.error('Failed to regenerate scene');
    }
  };

  const simulateDelay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 text-white">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Film className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                AI Movie Generator
              </h1>
              <p className="text-xs text-white/50">Create movies from prompts</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowTemplates(true)}
              className="text-white/70 hover:text-white hover:bg-white/10"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Templates
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowSettings(true)}
              className="text-white/70 hover:text-white hover:bg-white/10"
            >
              <Settings className="w-5 h-5" />
            </Button>
            <Badge variant="outline" className="border-purple-500/50 text-purple-300">
              <Brain className="w-3 h-3 mr-1" />
              AI Powered
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={currentTab} onValueChange={setCurrentTab} className="space-y-6">
          <TabsList className="bg-white/5 border border-white/10 p-1">
            <TabsTrigger value="create" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300">
              <Wand2 className="w-4 h-4 mr-2" />
              Create
            </TabsTrigger>
            <TabsTrigger value="script" disabled={!project?.script} className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300">
              <Clapperboard className="w-4 h-4 mr-2" />
              Script
            </TabsTrigger>
            <TabsTrigger value="scenes" disabled={!project?.scenes.length} className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300">
              <ImageIcon className="w-4 h-4 mr-2" />
              Scenes
            </TabsTrigger>
            <TabsTrigger value="preview" disabled={project?.status !== 'completed'} className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300">
              <Play className="w-4 h-4 mr-2" />
              Preview
            </TabsTrigger>
          </TabsList>

          {/* Create Tab */}
          <TabsContent value="create" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Input Section */}
              <div className="lg:col-span-2 space-y-6">
                <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Brain className="w-5 h-5 text-purple-400" />
                      Describe Your Movie Idea
                    </CardTitle>
                    <CardDescription className="text-white/50">
                      Be descriptive about characters, setting, plot, and mood for best results
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Textarea
                      placeholder="Describe your movie idea in detail... (e.g., 'A lone astronaut discovers an ancient alien civilization on a distant planet, unlocking secrets that could change humanity's future forever')"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="min-h-[180px] bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none"
                    />
                    
                    {/* Prompt Analysis */}
                    {promptAnalysis && (
                      <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                        <h4 className="text-sm font-medium text-purple-300 mb-2 flex items-center gap-2">
                          <TrendingUp className="w-4 h-4" />
                          AI Analysis
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline" className="border-purple-500/50 text-purple-300">
                            Genre: {promptAnalysis.genre}
                          </Badge>
                          <Badge variant="outline" className="border-purple-500/50 text-purple-300">
                            Mood: {promptAnalysis.mood}
                          </Badge>
                          <Badge variant="outline" className="border-purple-500/50 text-purple-300">
                            Suggested Scenes: {promptAnalysis.suggestedSceneCount}
                          </Badge>
                        </div>
                      </div>
                    )}

                    <div className="flex gap-3">
                      <Button
                        onClick={generateMovie}
                        disabled={isGenerating || !prompt.trim()}
                        className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
                      >
                        {isGenerating ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Generating...
                          </>
                        ) : (
                          <>
                            <Wand2 className="w-4 h-4 mr-2" />
                            Generate Movie
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setShowTemplates(true)}
                        className="border-white/20 text-white hover:bg-white/10"
                      >
                        <Sparkles className="w-4 h-4 mr-2" />
                        Templates
                      </Button>
                      {project && (
                        <Button
                          variant="outline"
                          onClick={resetProject}
                          className="border-white/20 text-white hover:bg-white/10"
                        >
                          <RefreshCw className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Generation Progress */}
                {isGenerating && project && (
                  <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Loader2 className="w-5 h-5 text-purple-400 animate-spin" />
                        Generating Your Movie
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-white/70">Overall Progress</span>
                          <span className="text-purple-400 font-medium">{project.progress}%</span>
                        </div>
                        <Progress value={project.progress} className="h-2 bg-white/10" />
                      </div>

                      {/* Generation Logs */}
                      <div className="bg-black/30 rounded-lg p-3 max-h-40 overflow-y-auto">
                        <h4 className="text-xs text-white/50 mb-2">Generation Logs</h4>
                        {generationLogs.map((log, index) => (
                          <p key={index} className="text-xs text-white/70 font-mono">{log}</p>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Sidebar */}
              <div className="space-y-6">
                {/* Quick Templates */}
                <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-white text-lg flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-purple-400" />
                      Quick Templates
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {movieTemplates.slice(0, 4).map((template) => (
                      <button
                        key={template.id}
                        onClick={() => applyTemplate(template)}
                        className="w-full text-left p-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-500/50 transition-all group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400 group-hover:text-purple-300">
                            {template.icon}
                          </div>
                          <div>
                            <p className="text-white font-medium text-sm">{template.name}</p>
                            <p className="text-white/50 text-xs">{template.description}</p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </CardContent>
                </Card>

                {/* Tips */}
                <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle className="text-white text-lg">Pro Tips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 text-sm text-white/70">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        Include character names and their goals
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        Describe the setting and atmosphere
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        Mention plot twists or emotional beats
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        Specify visual style preferences
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Script Tab */}
          <TabsContent value="script">
            {project?.script && (
              <div className="space-y-6">
                <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="text-white text-2xl">{project.script.title}</CardTitle>
                      <CardDescription className="text-white/50">
                        {project.script.genre} • {project.script.scenes.length} scenes
                      </CardDescription>
                    </div>
                    <Badge variant="outline" className="border-green-500/50 text-green-400">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Generated
                    </Badge>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Synopsis */}
                    <div className="bg-purple-500/10 rounded-lg p-4">
                      <h3 className="text-sm font-medium text-purple-300 mb-2">Synopsis</h3>
                      <p className="text-white/80">{project.script.synopsis}</p>
                    </div>

                    {/* Characters */}
                    <div>
                      <h3 className="text-sm font-medium text-white/70 mb-3">Characters</h3>
                      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {project.script.characters.map((char, index) => (
                          <div key={index} className="bg-white/5 rounded-lg p-4">
                            <div className="flex items-center gap-3 mb-2">
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                                {char.name[0]}
                              </div>
                              <div>
                                <p className="text-white font-medium">{char.name}</p>
                                <p className="text-xs text-white/50 capitalize">{char.voiceType} voice</p>
                              </div>
                            </div>
                            <p className="text-sm text-white/70">{char.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Scenes */}
                    <div>
                      <h3 className="text-sm font-medium text-white/70 mb-3">Scene Breakdown</h3>
                      <ScrollArea className="h-[400px] rounded-lg bg-black/30 p-4">
                        <div className="space-y-4">
                          {project.script.scenes.map((scene, index) => (
                            <div key={index} className="bg-white/5 rounded-lg p-4">
                              <div className="flex items-center justify-between mb-2">
                                <h4 className="text-white font-medium">Scene {scene.sceneNumber}: {scene.setting}</h4>
                                <div className="flex gap-2">
                                  <Badge variant="outline" className="text-xs border-white/20 text-white/50">
                                    {scene.mood}
                                  </Badge>
                                  <Badge variant="outline" className="text-xs border-white/20 text-white/50">
                                    {scene.lighting}
                                  </Badge>
                                </div>
                              </div>
                              <p className="text-sm text-white/70 mb-2">{scene.description}</p>
                              <p className="text-sm text-purple-300 italic mb-2">"{scene.narration}"</p>
                              {scene.dialogue.length > 0 && (
                                <div className="bg-black/30 rounded p-2 mt-2">
                                  {scene.dialogue.map((d, i) => (
                                    <p key={i} className="text-sm text-white/60">
                                      <span className="text-purple-400">{d.character}:</span> {d.line}
                                    </p>
                                  ))}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          {/* Scenes Tab */}
          <TabsContent value="scenes">
            {project?.scenes && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                    <ImageIcon className="w-5 h-5 text-purple-400" />
                    Generated Scenes ({project.scenes.length})
                  </h2>
                  <Button
                    variant="outline"
                    onClick={() => setCurrentTab('preview')}
                    className="border-purple-500/50 text-purple-300 hover:bg-purple-500/10"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Watch Preview
                  </Button>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {project.scenes.map((scene, index) => (
                    <Card key={scene.id} className="bg-white/5 border-white/10 backdrop-blur-sm overflow-hidden group">
                      <div className="relative aspect-video bg-black/50">
                        {scene.imageUrl ? (
                          <img
                            src={scene.imageUrl}
                            alt={`Scene ${index + 1}`}
                            className="w-full h-full object-cover transition-transform group-hover:scale-105"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
                          </div>
                        )}
                        <div className="absolute top-2 left-2">
                          <Badge className="bg-black/60 text-white border-0">
                            Scene {index + 1}
                          </Badge>
                        </div>
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            onClick={() => setSelectedScene(scene)}
                            className="bg-purple-500 hover:bg-purple-600"
                          >
                            <Play className="w-4 h-4 mr-1" />
                            View
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => regenerateScene(scene.id)}
                            className="border-white/30 text-white hover:bg-white/20"
                          >
                            <RefreshCw className="w-4 h-4 mr-1" />
                            Regen
                          </Button>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <p className="text-sm text-white/70 line-clamp-3">{scene.description}</p>
                        {scene.narration && (
                          <p className="text-xs text-purple-300 italic mt-2 line-clamp-2">
                            "{scene.narration}"
                          </p>
                        )}
                        <div className="flex items-center gap-2 mt-3">
                          <Badge variant="outline" className="text-xs border-white/20 text-white/50">
                            <Mic className="w-3 h-3 mr-1" />
                            {settings.voiceType}
                          </Badge>
                          <Badge variant="outline" className="text-xs border-white/20 text-white/50">
                            <Clock className="w-3 h-3 mr-1" />
                            {scene.duration}s
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          {/* Preview Tab */}
          <TabsContent value="preview">
            {project?.status === 'completed' && (
              <MoviePreview 
                project={project} 
                settings={settings}
                onExport={exportMovie}
              />
            )}
          </TabsContent>
        </Tabs>
      </main>

      {/* Templates Dialog */}
      <Dialog open={showTemplates} onOpenChange={setShowTemplates}>
        <DialogContent className="bg-slate-900 border-white/10 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              Movie Templates
            </DialogTitle>
            <DialogDescription className="text-white/50">
              Choose a template to get started quickly
            </DialogDescription>
          </DialogHeader>
          <div className="grid md:grid-cols-2 gap-4 py-4">
            {movieTemplates.map((template) => (
              <button
                key={template.id}
                onClick={() => applyTemplate(template)}
                className="text-left p-4 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-500/50 transition-all group"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400">
                    {template.icon}
                  </div>
                  <div>
                    <p className="text-white font-medium">{template.name}</p>
                    <p className="text-xs text-white/50">{template.settings.sceneCount} scenes • {template.settings.imageStyle}</p>
                  </div>
                </div>
                <p className="text-sm text-white/70">{template.description}</p>
              </button>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="bg-slate-900 border-white/10 text-white max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-purple-400" />
              Generation Settings
            </DialogTitle>
            <DialogDescription className="text-white/50">
              Customize how your movie is generated
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <Label className="text-white/70 flex items-center gap-2">
                <Target className="w-4 h-4" />
                Number of Scenes
              </Label>
              <div className="flex items-center gap-4">
                <Slider
                  value={[settings.sceneCount]}
                  onValueChange={([value]) => setSettings({ ...settings, sceneCount: value })}
                  min={3}
                  max={12}
                  step={1}
                  className="flex-1"
                />
                <span className="text-white font-medium w-8">{settings.sceneCount}</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 flex items-center gap-2">
                <Palette className="w-4 h-4" />
                Image Style
              </Label>
              <Select
                value={settings.imageStyle}
                onValueChange={(value: any) => setSettings({ ...settings, imageStyle: value })}
              >
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-white/10">
                  <SelectItem value="realistic">Realistic</SelectItem>
                  <SelectItem value="cinematic">Cinematic</SelectItem>
                  <SelectItem value="animated">Animated</SelectItem>
                  <SelectItem value="anime">Anime</SelectItem>
                  <SelectItem value="noir">Film Noir</SelectItem>
                  <SelectItem value="fantasy">Fantasy Art</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 flex items-center gap-2">
                <Mic className="w-4 h-4" />
                Voice Type
              </Label>
              <Select
                value={settings.voiceType}
                onValueChange={(value: any) => setSettings({ ...settings, voiceType: value })}
              >
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-white/10">
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="neutral">Neutral</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 flex items-center gap-2">
                <Music className="w-4 h-4" />
                Background Music
              </Label>
              <Select
                value={settings.musicGenre}
                onValueChange={(value: any) => setSettings({ ...settings, musicGenre: value })}
              >
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-white/10">
                  <SelectItem value="epic">Epic</SelectItem>
                  <SelectItem value="emotional">Emotional</SelectItem>
                  <SelectItem value="upbeat">Upbeat</SelectItem>
                  <SelectItem value="mysterious">Mysterious</SelectItem>
                  <SelectItem value="romantic">Romantic</SelectItem>
                  <SelectItem value="horror">Horror</SelectItem>
                  <SelectItem value="comedy">Comedy</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Pacing
              </Label>
              <Select
                value={settings.pacing}
                onValueChange={(value: any) => setSettings({ ...settings, pacing: value })}
              >
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-white/10">
                  <SelectItem value="slow">Slow (7s per scene)</SelectItem>
                  <SelectItem value="medium">Medium (5s per scene)</SelectItem>
                  <SelectItem value="fast">Fast (3s per scene)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between">
              <Label className="text-white/70 flex items-center gap-2">
                <Type className="w-4 h-4" />
                Include Narration
              </Label>
              <Switch
                checked={settings.includeNarration}
                onCheckedChange={(checked) => setSettings({ ...settings, includeNarration: checked })}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label className="text-white/70 flex items-center gap-2">
                <Users className="w-4 h-4" />
                Include Dialogue
              </Label>
              <Switch
                checked={settings.includeDialogue}
                onCheckedChange={(checked) => setSettings({ ...settings, includeDialogue: checked })}
              />
            </div>
          </div>

          <Button
            onClick={() => {
              setShowSettings(false);
              toast.success('Settings saved!');
            }}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            Save Settings
          </Button>
        </DialogContent>
      </Dialog>

      {/* Scene Detail Dialog */}
      <Dialog open={!!selectedScene} onOpenChange={() => setSelectedScene(null)}>
        <DialogContent className="bg-slate-900 border-white/10 text-white max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ImageIcon className="w-5 h-5 text-purple-400" />
              Scene {selectedScene ? project?.scenes.findIndex(s => s.id === selectedScene.id)! + 1 : ''}
            </DialogTitle>
          </DialogHeader>
          {selectedScene && (
            <div className="space-y-4">
              <div className="aspect-video rounded-lg overflow-hidden bg-black">
                {selectedScene.imageUrl && (
                  <img src={selectedScene.imageUrl} alt="Scene" className="w-full h-full object-cover" />
                )}
              </div>
              <div className="bg-white/5 rounded-lg p-4">
                <h4 className="text-sm font-medium text-white/70 mb-2">Description</h4>
                <p className="text-white">{selectedScene.description}</p>
              </div>
              {selectedScene.narration && (
                <div className="bg-purple-500/10 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-purple-300 mb-2">Narration</h4>
                  <p className="text-white/80 italic">"{selectedScene.narration}"</p>
                </div>
              )}
              {selectedScene.dialogue && (
                <div className="bg-white/5 rounded-lg p-4">
                  <h4 className="text-sm font-medium text-white/70 mb-2">Dialogue</h4>
                  <p className="text-white/80">{selectedScene.dialogue}</p>
                </div>
              )}
              <div className="flex gap-2">
                <Button
                  onClick={() => selectedScene && regenerateScene(selectedScene.id)}
                  variant="outline"
                  className="flex-1 border-white/20 text-white hover:bg-white/10"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Regenerate Scene
                </Button>
                <Button
                  onClick={() => setSelectedScene(null)}
                  className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Done
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
